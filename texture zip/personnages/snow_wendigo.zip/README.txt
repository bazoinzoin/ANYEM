Thank you for purchasing this asset pack!
I hope you enjoy using it in your project. If you have any questions or feedback, feel free to reach out. You can contact me at aldanaloureyro2@gmail.com

https://akari21.itch.io/wendigo

License:
You can use these assets in any personal or commercial project.
You may edit or modify them to suit your needs.
You may not resell or redistribute the assets as-is or in modified form.

Credits are very appreciated, but not required.